function [z,alpha] = LDNR(X, y, param, trls)

    lambda = param.lambda;
    mu = param.mu;
    sigma = param.sigma;
    class_num = param.class_num;
    
    [~, n] = size(X);
    tol = 1e-5;
    maxIter = 5;
    
    alpha = zeros(n, 1);
    z = alpha;
    delta = alpha;

    [w] = Weight(y, X, trls, sigma);
    
    tr_sym_mat = zeros(length(trls));
    for ci = 1 : class_num
        ind_ci = find(trls == ci);
        tr_descr_bar = zeros(size(X));
        tr_descr_bar(:, ind_ci) = X(:, ind_ci);
        tr_sym_mat = tr_sym_mat + w(ci) * (tr_descr_bar' * tr_descr_bar);
    end

    P = X' * X + lambda * tr_sym_mat + mu / 2 * eye(n);
        
    iter = 0;
    while iter < maxIter
        
        iter = iter + 1;

        z_k = z;
        alpha_k = alpha;
        
        alpha = P \ (X' * y + mu / 2 * z + delta / 2);
        z = max(0, alpha - delta / mu);

        leq1 = z - alpha;
        leq2 = z - z_k;
        leq3 = alpha - alpha_k;
        
        stopC1 = max(norm(leq1), norm(leq2));
        stopC = max(stopC1, norm(leq3));

        if stopC < tol || iter >= maxIter
            break;
        else
            delta = delta + mu * leq1;
        end
    end
end
