function residual = LDNR_res(X,y,alpha,trls)
    ClassNum = length(unique(trls));
    train_tol = size(X,2);

    W = sparse([],[],[],train_tol,ClassNum,length(alpha));

    for j=1:ClassNum
        ind = (j==trls);
        W(ind,j) = alpha(ind);
    end

    temp = X*W-repmat(y,1,ClassNum);
    residual = sqrt(sum(temp.^2));
end
