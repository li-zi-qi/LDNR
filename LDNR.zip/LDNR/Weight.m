function [D,Res] = Weight(y, X, trls, sigma)

    XTX = X' * X;
    Proj = pinv(XTX + 0.01 * size(X,2)) * X';
    Xs = Proj * y;

    class_num = numel(unique(trls));
    Res = zeros(class_num, 1);
    
    for i=1:class_num
        pos = find(trls == i);
        Xi  = Xs(pos);
        e = norm(y - X(:, pos) * Xi, 2);
        Res(i) = e;
    end

    D = exp(Res / max(Res) / sigma);
end
