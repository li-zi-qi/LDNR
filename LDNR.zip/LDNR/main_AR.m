clear
clc
close all

load('data/AR_DAT.mat');

%--------------------------------------------------------------------------

Tr_DAT = double(NewTrain_DAT);
trls = trainlabels;
Tt_DAT = double(NewTest_DAT);
ttls = testlabels;

train_tol= size(Tr_DAT,2);
test_tol = size(Tt_DAT,2);

%--------------------------------------------------------------------------

dims = 120;
param = [];

param.lambda = 1e-2;
param.mu = 0.1;
param.sigma = 10;
param.class_num = length(unique(trls));

%--------------------------------------------------------------------------

for dim = dims
    
    [disc_set, disc_value, Mean_Image]  =  Eigenface_f(Tr_DAT, dim);
    tr_dat  =  disc_set' * Tr_DAT;
    tt_dat  =  disc_set' * Tt_DAT;
    tr_dat = normc(tr_dat);
    tt_dat = normc(tt_dat);
    
    X = tr_dat;
    ID = zeros(1, test_tol);
    
    parfor i = 1:test_tol

        y = tt_dat(:, i);
        
        [~, alpha] = LDNR(X, y, param, trls);

        residuals = LDNR_res(X, y, alpha, trls);

        [~, index] = min(residuals);

        ID(i) = index;
    end

    cornum = sum(ID == ttls);
    Rec = cornum / length(ttls);
    
    fprintf('dim = %d, rec = %.2f\n', dim, Rec * 100);
end
